</div> <!-- container -->
	

	<!-- file input -->
	<script src="assets/plugins/fileinput/js/plugins/canvas-to-blob.min.js'); ?>" type="text/javascript"></script>	
	<script src="assets/plugins/fileinput/js/plugins/sortable.min.js" type="text/javascript"></script>	
	<script src="assets/plugins/fileinput/js/plugins/purify.min.js" type="text/javascript"></script>
	<script src="assets/plugins/fileinput/js/fileinput.min.js"></script>	


	<!-- DataTables -->
	<script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>

</body>
</html>